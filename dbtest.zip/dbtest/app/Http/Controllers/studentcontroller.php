<?php

namespace App\Http\Controllers;
use App\Models\student;
use App\Models\User;
use App\Models\admin;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class studentcontroller extends Controller
{
    function home()
    {
        return view('home');
    }
    function add(Request $req)
    {
        $r1 = new student;
        $r1->sname=$req->input('sname');
        $r1->fname=$req->input('fname');
        $r1->age=$req->input('age');
        $r1->address=$req->input('address');
        $r1->phone=$req->input('phone');
        $r1->save();
        $req->session()->flash('status','Student Added Successfully!!!');
        return redirect('list');
        
    }
    function list()
    {
        $data = student::all();
        return view('list',['data'=>$data]);
    }

    function delete($id)
    {
        echo student::find($id)->delete();
        Session()->flash('status','Student Deleted Successfully!');
        return redirect('list');
    }

    function edit($id)
    {
        $data = student::find($id);
        return view('edit',['data'=>$data]);
    }
    function update(Request $req)
    {
        $r1 = student::find($req->input('id'));
        $r1->sname=$req->input('sname');
        $r1->fname=$req->input('fname');
        $r1->age=$req->input('age');
        $r1->address=$req->input('address');
        $r1->phone=$req->input('phone');
        $r1->save();
        $req->session()->flash('status','Student Updated Successfully!!!');
        return redirect('list');
    }

    function register(Request $req){
        $req->validate([
            "name"=>"required|string",
            "email"=>"required|unique:users|email",
            "password"=>"required| min:8",
            "phone"=>"required|numeric| min:11"
        ]);
        $u1 = new User;
        $u1->name=$req->input('name');
        $u1->email=$req->input('email');
        $u1->password=$req->input('password');
        $u1->phone=$req->input('phone');
        $u1->save();
        $req->session()->put('u1',$req->input('name'));
        return redirect('/');
    }
    function showregistration()
    {
        return view('registration');
    }
    function registration(Request $req)
    {
        $req->validate([
            "name"=>"required|string",
            "email"=>"required|unique:users|email",
            "password"=>"required| min:8",
        ]);

        User::create([
            'name'=> $req->name,
            'email' => $req->email,
            'password' =>Hash::make($req->password)
        ]);
        return redirect('signin');
    }

    function showsignin()
    {
        return view('signin');
    }

    function signin(Request $req)
    {
        $req->validate([
            "email"=>"required | email",
            "password"=>"required"
        ]);
        if(!Auth::attempt(['email' => $req->email , 'password'=>$req->password ])){
            $req->session()->flash('status','Credential Not Match!');
                 return redirect()->route('signin');
        }
        elseif(auth()->user()->isAdmin == 1)
        {
             return redirect()->route('teacherdash');
        }elseif(auth()->user()->isAdmin == 0)
        {
            return redirect()->route('studentdash');
        }
    }
    function logout()
    {
        Auth::logout();
        return redirect()->route('signin');
    }
    function login(Request $req){
        $req->validate([
            "email"=>"required | email",
            "password"=>"required"
        ]);

      
            
        
        



        // $u1 = User::where('email', request('email'))->get();
        // Hash::check(request('password'), $u1->password);
       
        // $type = ['$email','$password'];

        // $u1 = User::where('email',$req->input('email'))->get();
        // if($u1[0]->password == $req->input('password'))
        // {
        //     $req->session()->put('u1',$u1[0]->name);
        //     return redirect('/admin');
        // }else{
        //     $req->session()->flash('status','Credential Not Match!');
        //     return redirect('/login');
        // }
       
    }

    function verifyemailpasswordreset(Request $req)
    {
        
        $u1 = User::where('email','=',$req->input('email'))->first();
            
        if($u1)
        {
            // $data = User::where('id','=',$req->input('email'))->first();
            return redirect('/resetpassword');
        }else{
            $req->session()->flash('status','Credentials Not Match!');
            return redirect('/verifyemailpasswordreset');
        }
    }
    function editresetpassword($std_id)
    {
        $data = User::find($std_id);
        return view('resetpassword',['data'=>$data]);
    }
    function resetpassword(Request $req)
    {
        $u1 = User::find($req->input('std_id'));
        // $u1 = User::where('id','=',$req->input('email'))->first();
        // $u1 = User::where('password',$req->input('oldpassword'))->get();
            
        // if($u1)
        // {
            // $req->session()->put('u1',$u1[0]->name);
            // $u1 = new User;
            $u1->password=$req->input('newpassword');
            $u1->save();
            // $req->session()->put('u1',$req->input('name'));
            $req->session()->flash('statuss','Password Has been Changed!');
            return redirect('/login');
        // }else{
        //     $req->session()->flash('status','Old Password not match!');
        //     return redirect('/resetpassword');
        // }    
    }

}
