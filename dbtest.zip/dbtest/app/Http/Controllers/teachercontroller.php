<?php

namespace App\Http\Controllers;
use App\Models\student;
use App\Models\User;
use App\Models\admin;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class teachercontroller extends Controller
{
    function home()
    {
        return view('home');
    }
    function add(Request $req)
    {
        $r1 = new student;
        $r1->sname=$req->input('sname');
        $r1->fname=$req->input('fname');
        $r1->age=$req->input('age');
        $r1->address=$req->input('address');
        $r1->phone=$req->input('phone');
        $r1->save();
        $req->session()->flash('status','Student Added Successfully!!!');
        return redirect('list');
        
    }
    function list()
    {
        $data = student::all();
        return view('list',['data'=>$data]);
    }

    function delete($id)
    {
        echo student::find($id)->delete();
        Session()->flash('status','Student Deleted Successfully!');
        return redirect('list');
    }

    function edit($id)
    {
        $data = student::find($id);
        return view('edit',['data'=>$data]);
    }
    function update(Request $req)
    {
        $r1 = student::find($req->input('id'));
        $r1->sname=$req->input('sname');
        $r1->fname=$req->input('fname');
        $r1->age=$req->input('age');
        $r1->address=$req->input('address');
        $r1->phone=$req->input('phone');
        $r1->save();
        $req->session()->flash('status','Student Updated Successfully!!!');
        return redirect('list');
    }
    function showregistration()
    {
        return view('registration');
    }
    function registration(Request $req)
    {
        $req->validate([
            "name"=>"required|string",
            "email"=>"required|unique:users|email",
            "password"=>"required| min:8",
        ]);

        User::create([
            'name'=> $req->name,
            'email' => $req->email,
            'password' =>Hash::make($req->password)
        ]);
        return redirect('signin');
    }

    function showsignin()
    {
        return view('signin');
    }
    function signin(Request $req)
    {
        $req->validate([
            "email"=>"required | email",
            "password"=>"required"
        ]);
        if(!Auth::attempt(['email' => $req->email , 'password'=>$req->password ])){
            $req->session()->flash('status','Credential Not Match!');
                 return redirect()->route('signin');
        }

        return redirect()->route('teacherdash');
    }
    function logout()
    {
        Auth::logout();
        return redirect()->route('signin');
    }
}
