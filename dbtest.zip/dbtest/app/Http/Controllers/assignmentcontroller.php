<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\assignment;
use Illuminate\Support\Facades\Storage;


class assignmentcontroller extends Controller
{
    function addassignment(Request $req)
    {  
        $as1 = new assignment;
        $file = $req->file;
        $filename = time(). '.' . $file->getClientOriginalExtension();
        $req->file->move('assets', $filename);
        $as1->file = $filename;

        $as1->title=$req->input('title');
        $as1->description=$req->input('description');
        $as1->deadline=$req->input('deadline');
        $as1->save();
        $req->session()->flash('status','Assignment has been successfully!!!');
        return redirect('addassignment');
    }
    function viewfile($id)
        {
            $data = assignment::find($id);
            return view('viewfile',['data'=>$data]);
        }
    
    function viewassignments()
    {
        $data = assignment::all();
        return view('viewassignments',['data'=>$data]);
    }
    function deleteassignment($id)
    {
        echo assignment::find($id)->delete();
        Session()->flash('status','Assignment Deleted Successfully!');
        return redirect('viewassignments');
    }
    function viewstdassignment()
    {
        $data = assignment::all();
        return view('viewstdassignment',['data'=>$data]);   
    }
    function addstdassignment(Request $req)
    {
        $as1 = new assignment;
        $stdfile = $req->stdfile;
        $filename = time(). '.' . $stdfile->getClientOriginalExtension();
        $req->stdfile->move('assets', $filename);
        $as1->stdfile = $filename;
        $as1->save();

        return redirect('/viewstdassignment');
    }
  
}
