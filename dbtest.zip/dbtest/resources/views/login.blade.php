@extends('layout')


@section('content')

<div class="col-sm-6">
    <h1>Login Student</h1>
    @if(Session::get('status'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
       {{Session::get('status')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    @if(Session::get('statuss'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
       {{Session::get('statuss')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    <form method="post" action="/login" >
        @csrf
        <!-- <li style="margin-left:700px;" class="nav-item dropdown">
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="#">Profile</a>
                <a class="dropdown-item" href="/logout">Logout</a>
            </div>
        </li> -->
        <!-- <div style="width:50px;">
            <select name="type" id="type">
                <option value="type">type ..</option>
                <option name="admin" value="admin">admin</option>
                <option name="student" value="student">student</option>
                <option value="teacher">teacher</option>
                
            </select>
        </div> -->
        <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email">
            <div class = " alert-danger">
           @error('email')
            <div>{{$message}}</div>
            @enderror
           </div>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter Password">
           <div class = " alert-danger">
           @error('password')
            <div>{{$message}}</div>
            @enderror
           </div>
        </div>
        <button style="background-color:#0f0f0a;" type="submit" class="btn btn-primary">Login</button>
        <a style="float:right" href="/verifyemailpasswordreset">Forget Your Password?</a>
        </form>
</div>

@stop