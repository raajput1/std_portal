@extends('layout')


@section('content')

<div class="col-sm-6">
    <h1>Verifiy Email First</h1>
    @if(Session::get('status'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
       {{Session::get('status')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    <form method="post" action="/verifyemailpasswordreset" >
        @csrf
        <div class="form-group">
            <label>Enter Email</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email">
            <!-- <div class = " alert-danger">
           @error('email')
            <div>{{$message}}</div>
            @enderror
           </div> -->
        </div>
        <button type="submit" class="btn btn-primary">Verify</button>
    </form>


    
</div>





@stop