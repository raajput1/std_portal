@extends('layout')


@section('content')

<div class="col-sm-6">
    <h1>Register Student</h1>
    <form method="post" action="/register" >
        @csrf
        <div class="form-group" >
            <label>Student Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Student Name">
            <div class = " alert-danger">
           @error('name')
            <div>{{$message}}</div>
            @enderror
           </div>
        </div>
        <div class="form-group">
            <label>email</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email">
            <div class = "alert-danger">
           @error('email')
            <div>{{$message}}</div>
            @enderror
           </div>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter Password">
            <div class = " alert-danger">
           @error('password')
            <div>{{$message}}</div>
            @enderror
           </div>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" placeholder="Enter Phone">
            <div class = " alert-danger">
           @error('phone')
            <div>{{$message}}</div>
            @enderror
           </div>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
        </form>
</div>

@stop