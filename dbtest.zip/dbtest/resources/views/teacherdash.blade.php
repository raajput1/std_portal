
@extends('layout')


@section('content')

<div>
    <h1>Teacher Dashboard</h1>
</div>

@stop