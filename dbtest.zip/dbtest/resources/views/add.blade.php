@extends('layout')


@section('content')

<div class="col-sm-6">
    <h1>Add Student</h1>
    <form method="post" action="/add" >
        @csrf
        <div class="form-group" >
            <label>Full Name</label>
            <input type="text" name="sname" class="form-control" placeholder="Enter Student Name">
        </div>
        <div class="form-group">
            <label>Father Name</label>
            <input type="text" name="fname" class="form-control" placeholder="Enter Father Name">
        </div>
        <div class="form-group">
            <label>Age</label>
            <input type="text" name="age" class="form-control" placeholder="Enter Student Age">
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" class="form-control" placeholder="Enter Student Address">
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" placeholder="Enter Father's Phone No">
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
</div>

@stop