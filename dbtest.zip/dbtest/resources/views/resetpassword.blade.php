@extends('layout')


@section('content')

<div class="col-sm-6">
    <h1>Forget Password</h1>
    @if(Session::get('status'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
       {{Session::get('status')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    <form method="post" action="/resetpassword" >
        @csrf
        <!-- <div class="form-group">
            <label>Old Password</label>
            <input type="password" name="oldpassword" class="form-control" placeholder="Enter Old Password"> -->
            <!-- <div class = " alert-danger">
           @error('email')
            <div>{{$message}}</div>
            @enderror
           </div> -->
        <!-- </div> -->
        <div class="form-group">
            <label>New Password</label>
            <input type="text" name="id" value="{{$data->id}}">
            <input type="password" name="newpassword" class="form-control" placeholder="Enter New Password">
           <!-- <div class = " alert-danger">
           @error('password')
            <div>{{$message}}</div>
            @enderror
           </div> -->
        </div>
        <!-- <div class="form-group">
            <label>Confirm New Password</label>
            <input type="password" name="confirmnewpassword" class="form-control" placeholder="Enter Confirm Password"> -->
           <!-- <div class = " alert-danger">
           @error('password')
            <div>{{$message}}</div>
            @enderror
           </div> -->
        <!-- </div> -->
        <button  type="submit" class="btn btn-primary">Reset</button>
        </form>
</div>

@stop