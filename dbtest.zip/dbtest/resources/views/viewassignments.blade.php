@extends('layout')


@section('content')

<div>
    <h1>Assignments Detail</h1>
    @if(Session::get('status'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
       {{Session::get('status')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Assignment Title</th>
      <th scope="col">Description</th>
      <th scope="col">Deadline</th>
      <th scope="col">File</th>
      <th scope="col">Student Upload</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>
    @foreach($data as $item)
    <tr>
      <th scope="row">{{$item->id}}</th>
      <td>{{$item->title}}</td>
      <td>{{$item->description}}</td>
      <td>{{$item->deadline}}</td>
      
      <td> 
            <a href="/viewfile/{{$item->id}}">{{$item->file}}</a>
            <a href="/edit/{{$item->id}}"><i class="fa fa-download"></i></a>
      </td>
      <td>{{$item->title}}</td>
      <td>
        <a href="/edit/{{$item->id}}"><i class="fa fa-edit"></i></a>
        <a href="/deleteassignment/{{$item->id}}"><i class="fa fa-trash"></i></a>
      </td>
    
    </tr>
    @endforeach
  </tbody>
</table>


</div>

@stop