@extends('layout')


@section('content')

<div class="col-sm-6">
    <h1>Add Assignment</h1>
    @if(Session::get('status'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
       {{Session::get('status')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif
    <form method="post" action="/addassignment" enctype="multipart/form-data">
        @csrf
        <div class="form-group" >
            <label>Title</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Assignment Title">
        </div>
        <div class="form-group">
            <label>Description</label>
            <input type="text" name="description" class="form-control" placeholder="Enter Description">
        </div>
        <div class="form-group">
            <label>Deadline</label>
            <input type="datetime-local" name="deadline" class="form-control" >
        </div>
        <div class="form-group">
            <label>Select File</label>
            <input type="file" name="file" class="form-control" >
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
</div>

@stop
