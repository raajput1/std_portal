@extends('layout')


@section('content')

<div>
    <h1>Home Content Will Be Here!!!</h1>
</div>

@stop