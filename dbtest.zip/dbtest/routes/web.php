<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\studentcontroller;
use App\Models\student;
use App\Http\Controllers\assignmentcontroller;
use SebastianBergmann\CodeCoverage\Report\Xml\Facade;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('home');
// });

// Route::get('/',[studentcontroller::class,'home']);
// Route::post('/add',[studentcontroller::class,'add']);
// Route::view('/add','add');



Route::view('/register','register');
Route::post('/register',[studentcontroller::class,'register']);
Route::view('/login','login');
Route::post('/login',[studentcontroller::class,'login']);
// Route::get('/logout', function () {
//     if(session()->has('u1')){
//         session()->pull('u1',null);
//     }
//     return redirect()->route('signin');
// });

// Route::view('/verifyemailpasswordreset','verifyemailpasswordreset');
Route::get('/verifyemailpasswordreset',[studentcontroller::class,'verifyemailpasswordreset']);
Route::post('/verifyemailpasswordreset',[studentcontroller::class,'verifyemailpasswordreset']);


// Route::get('/resetpassword/{email}','editresetpassword');
Route::view('/resetpassword','resetpassword');
Route::get('/resetpassword/{id}',[studentcontroller::class,'editresetpassword']);
Route::post('/resetpassword',[studentcontroller::class,'resetpassword']);



// Route::get('/admin', function () {
//     return view('admindashboard');
// })->name('admin')->middleware('admin');


Route::get('/registration',[studentcontroller::class,'showregistration'])->name('registration');
Route::post('/registration',[studentcontroller::class,'registration']);
Route::get('/signin',[studentcontroller::class,'showsignin'])->name('signin');
Route::post('/signin',[studentcontroller::class,'signin']);
Route::get('/logout',[studentcontroller::class,'logout'])->name('logout');

Route::get('/teacherdash', function () {
    return view('teacherdash');
})->name('teacherdash')->middleware('teacherdash');
Route::get('/studentdash', function () {
    return view('studentdash');
})->name('studentdash')->middleware('teacherdash');

// Route::view('/viewassignments','viewassignments');

Route::view('/addassignment','addassignment');
Route::post('/addassignment',[assignmentcontroller::class,'addassignment']);
Route::view('/viewassignments','viewassignments');
Route::get('/viewassignments',[assignmentcontroller::class,'viewassignments']);
Route::get('/deleteassignment/{id}',[assignmentcontroller::class,'deleteassignment']);
Route::get('/viewfile/{id}',[assignmentcontroller::class,'viewfile']);

Route::get('/viewstdassignment', [assignmentcontroller::class, 'viewstdassignment']);
Route::post('/viewstdassignment', [assignmentcontroller::class, 'addstdassignment']);

Route::group(['middleware'=>"web"],function(){

});
Route::middleware(['auth'])->group(function (){
    Route::post('/add',[studentcontroller::class,'add']);
    Route::view('/add','add');
    Route::view('/list','list');
Route::get('/list',[studentcontroller::class,'list']);
Route::get('/delete/{id}',[studentcontroller::class,'delete']);
Route::get('/edit/{id}',[studentcontroller::class,'edit']);
Route::post('/edit',[studentcontroller::class,'update']);
    // Route::resource('/add',studentcontroller::class);
});
