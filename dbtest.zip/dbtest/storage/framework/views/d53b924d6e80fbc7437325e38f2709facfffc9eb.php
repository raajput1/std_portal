



<?php $__env->startSection('content'); ?>

<div>
    <h1>Teacher Dashboard</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/teacherdash.blade.php ENDPATH**/ ?>