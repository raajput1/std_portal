


<?php $__env->startSection('content'); ?>

<div class="col-sm-6">
    <h1>Add Assignment</h1>
    <?php if(Session::get('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
       <?php echo e(Session::get('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <form method="post" action="/addassignment" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group" >
            <label>Title</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Assignment Title">
        </div>
        <div class="form-group">
            <label>Description</label>
            <input type="text" name="description" class="form-control" placeholder="Enter Description">
        </div>
        <div class="form-group">
            <label>Deadline</label>
            <input type="datetime-local" name="deadline" class="form-control" >
        </div>
        <div class="form-group">
            <label>Select File</label>
            <input type="file" name="file" class="form-control" >
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/addassignment.blade.php ENDPATH**/ ?>