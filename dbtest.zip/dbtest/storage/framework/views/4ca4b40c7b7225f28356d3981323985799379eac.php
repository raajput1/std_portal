


<?php $__env->startSection('content'); ?>

<div>
    <h1>Listing Detail</h1>
    <?php if(Session::get('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
       <?php echo e(Session::get('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Student Name</th>
      <th scope="col">Father Name</th>
      <th scope="col">Age</th>
      <th scope="col">Address</th>
      <th scope="col">Phone No.</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($item->id); ?></th>
      <td><?php echo e($item->sname); ?></td>
      <td><?php echo e($item->fname); ?></td>
      <td><?php echo e($item->age); ?></td>
      <td><?php echo e($item->address); ?></td>
      <td><?php echo e($item->phone); ?></td>
      <td>
        <a href="/edit/<?php echo e($item->id); ?>"><i class="fa fa-edit"></i></a>
        <a href="/delete/<?php echo e($item->id); ?>"><i class="fa fa-trash"></i></a>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/list.blade.php ENDPATH**/ ?>