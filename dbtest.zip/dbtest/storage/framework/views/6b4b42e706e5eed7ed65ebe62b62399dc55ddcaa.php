


<?php $__env->startSection('content'); ?>

<div class="col-sm-6">
    <h1>Edit Student</h1>
    <form method="post" action="/edit" >
        <?php echo csrf_field(); ?>
        <div class="form-group" >
            <label>Full Name</label>
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <input type="text" name="sname" class="form-control" value="<?php echo e($data->sname); ?>" placeholder="Enter Student Name">
        </div>
        <div class="form-group">
            <label>Father Name</label>
            <input type="text" name="fname" class="form-control" value="<?php echo e($data->fname); ?>" placeholder="Enter Father Name">
        </div>
        <div class="form-group">
            <label>Age</label>
            <input type="text" name="age" class="form-control" value="<?php echo e($data->age); ?>" placeholder="Enter Student Age">
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo e($data->address); ?>" placeholder="Enter Student Address">
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e($data->phone); ?>" placeholder="Enter Father's Phone No">
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
        </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/edit.blade.php ENDPATH**/ ?>