


<?php $__env->startSection('content'); ?>

<div class="col-sm-6">
    <h1>Login Student</h1>
    <?php if(Session::get('status')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
       <?php echo e(Session::get('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('signin')); ?>" >
        <?php echo csrf_field(); ?>
        <!-- <li style="margin-left:700px;" class="nav-item dropdown">
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="#">Profile</a>
                <a class="dropdown-item" href="/logout">Logout</a>
            </div>
        </li> -->
        <!-- <div style="width:50px;">
            <select name="type" id="type">
                <option value="type">type ..</option>
                <option name="admin" value="admin">admin</option>
                <option name="student" value="student">student</option>
                <option value="teacher">teacher</option>
                
            </select>
        </div> -->
        <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email">
            <div class = " alert-danger">
           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           </div>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter Password">
           <div class = " alert-danger">
           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           </div>
        </div>
        <button style="background-color:#0f0f0a;" type="submit" class="btn btn-primary">Login</button>
        <a style="float:right" href="/verifyemailpasswordreset">Forget Your Password?</a>
        </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/signin.blade.php ENDPATH**/ ?>