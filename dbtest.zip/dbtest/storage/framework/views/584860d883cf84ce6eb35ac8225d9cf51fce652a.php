


<?php $__env->startSection('content'); ?>

<div>
    <h1>Assignments Detail</h1>
    <?php if(Session::get('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
       <?php echo e(Session::get('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Assignment Title</th>
      <th scope="col">Description</th>
      <th scope="col">Deadline</th>
      <th scope="col">File</th>
      <th scope="col">Student Upload</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($item->id); ?></th>
      <td><?php echo e($item->title); ?></td>
      <td><?php echo e($item->description); ?></td>
      <td><?php echo e($item->deadline); ?></td>
      
      <td> 
            <a href="/viewfile/<?php echo e($item->id); ?>"><?php echo e($item->file); ?></a>
            <a href="/edit/<?php echo e($item->id); ?>"><i class="fa fa-download"></i></a>
      </td>
      <td><?php echo e($item->title); ?></td>
      <td>
        <a href="/edit/<?php echo e($item->id); ?>"><i class="fa fa-edit"></i></a>
        <a href="/deleteassignment/<?php echo e($item->id); ?>"><i class="fa fa-trash"></i></a>
      </td>
    
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/viewassignments.blade.php ENDPATH**/ ?>