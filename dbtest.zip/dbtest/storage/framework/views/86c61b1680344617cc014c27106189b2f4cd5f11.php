<?php echo $__env->make('studentheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<h1>Student DashBoard</h1><?php /**PATH C:\Users\Raaye\Desktop\laravels\dbtest\resources\views/studentdash.blade.php ENDPATH**/ ?>